package br.com.MarcosHenriqueRS10.obrasdearte.ui.main

import DetalheActivity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import br.com.MarcosHenriqueRS10.obrasdearte.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()

    private lateinit var adapter: MainListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        configuraLista()
    }

    private fun configuraLista() {
        adapter = MainListAdapter(
            onClick = { obra ->
                Toast.makeText(
                    this,
                    "Você clicou na ${obra.titulo}",
                    Toast.LENGTH_LONG
                ).show()
            }
        )
        binding.rvObrasDeArte.layoutManager =
            LinearLayoutManager(this)
        binding.rvObrasDeArte.adapter = adapter
        viewModel.lista.observe(this) { obras ->
            adapter.submitList(obras)
        }
        adapter = MainListAdapter(
            onClick = { obra ->
                val detalheIntent = Intent(this, DetalheActivity::class.java)
                    .apply {
                        putExtra(DetalheActivity.EXTRA_OBRA_ARTE, obra)
                    }
                startActivity(detalheIntent)
            }
        )
    }
}
